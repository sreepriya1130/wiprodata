using Microsoft.AspNetCore.Identity;

namespace RoleBasedProductMgmt.Models
{
    public class ApplicationUser : IdentityUser
    {
    }
}

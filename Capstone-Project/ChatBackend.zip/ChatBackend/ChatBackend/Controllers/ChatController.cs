﻿using ChatBackend.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ChatBackend.Data;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;

namespace ChatBackend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class ChatController : ControllerBase
    {
        private readonly ApplicationDbContext _db;
        private readonly UserManager<User> _um;

        public ChatController(ApplicationDbContext db, UserManager<User> um)
        {
            _db = db;
            _um = um;
        }

        // ✅ Fetch private messages between logged-in user and another user (by DisplayName)
        [HttpGet("private/{displayName}")]
        public async Task<IActionResult> GetPrivate(string displayName)
        {
            var meId = User.FindFirstValue(ClaimTypes.NameIdentifier)
                       ?? User.FindFirstValue(JwtRegisteredClaimNames.Sub);

            if (string.IsNullOrEmpty(meId))
                return Unauthorized("Could not determine logged-in user ID.");

            var otherUser = await _um.Users
                .FirstOrDefaultAsync(u => u.DisplayName == displayName || u.UserName == displayName);

            if (otherUser == null) return NotFound("User not found");

            // Fetch messages
            var msgs = await _db.Messages
                .Where(m => (m.SenderId == meId && m.ReceiverId == otherUser.Id) ||
                            (m.SenderId == otherUser.Id && m.ReceiverId == meId))
                .OrderBy(m => m.SentAtUtc)
                .ToListAsync();

            // Map userIds to display names
            var userIds = msgs.Select(m => m.SenderId)
                              .Concat(msgs.Where(m => m.ReceiverId != null).Select(m => m.ReceiverId!))
                              .Distinct()
                              .ToList();

            var users = await _um.Users
                .Where(u => userIds.Contains(u.Id))
                .ToDictionaryAsync(u => u.Id, u => u.DisplayName ?? u.UserName ?? u.Email);

            return Ok(msgs.Select(m => new
            {
                m.Id,
                Sender = users.ContainsKey(m.SenderId) ? users[m.SenderId] : null,
                Receiver = (m.ReceiverId != null && users.ContainsKey(m.ReceiverId)) ? users[m.ReceiverId] : null,
                m.Content,
                m.GroupId,
                m.SentAtUtc
            }));
        }

        // DTO for sending a message
        public record SendDto(string? ReceiverDisplayName, int? GroupId, string Content);

        // ✅ Send a message (private or group)
        [HttpPost("send")]
        public async Task<IActionResult> Send([FromBody] SendDto dto)
        {
            var meId = User.FindFirstValue(ClaimTypes.NameIdentifier)
                       ?? User.FindFirstValue(JwtRegisteredClaimNames.Sub);

            if (string.IsNullOrEmpty(meId))
                return Unauthorized("Could not determine logged-in user ID.");

            // Validate group if GroupId is provided
            if (dto.GroupId.HasValue)
            {
                var group = await _db.Groups.FindAsync(dto.GroupId.Value);
                if (group == null)
                    return BadRequest($"Group with Id {dto.GroupId} does not exist.");
            }

            string? receiverId = null;
            if (!string.IsNullOrEmpty(dto.ReceiverDisplayName))
            {
                var receiver = await _um.Users
                    .FirstOrDefaultAsync(u => u.DisplayName == dto.ReceiverDisplayName || u.UserName == dto.ReceiverDisplayName);

                if (receiver == null) return NotFound("Receiver not found");
                receiverId = receiver.Id;
            }

            if (string.IsNullOrWhiteSpace(dto.Content))
                return BadRequest("Message content cannot be empty.");

            var msg = new Message
            {
                SenderId = meId,
                ReceiverId = receiverId,
                GroupId = dto.GroupId,
                Content = dto.Content,
                SentAtUtc = DateTime.UtcNow
            };

            _db.Messages.Add(msg);
            await _db.SaveChangesAsync();

            var sender = await _um.FindByIdAsync(meId);

            return Ok(new
            {
                msg.Id,
                Sender = sender?.DisplayName ?? sender?.UserName ?? "Unknown",
                Receiver = dto.ReceiverDisplayName,
                msg.GroupId,
                msg.Content,
                msg.SentAtUtc
            });
        }

        // ✅ Fetch group messages (returns DisplayNames)
        [HttpGet("group/{groupId:int}")]
        public async Task<IActionResult> GetGroup(int groupId)
        {
            var group = await _db.Groups.FindAsync(groupId);
            if (group == null) return NotFound($"Group with Id {groupId} does not exist.");

            var msgs = await _db.Messages
                .Where(m => m.GroupId == groupId)
                .OrderBy(m => m.SentAtUtc)
                .ToListAsync();

            var userIds = msgs.Select(m => m.SenderId).Distinct().ToList();

            var users = await _um.Users
                .Where(u => userIds.Contains(u.Id))
                .ToDictionaryAsync(u => u.Id, u => u.DisplayName ?? u.UserName ?? u.Email);

            return Ok(msgs.Select(m => new
            {
                m.Id,
                Sender = users.ContainsKey(m.SenderId) ? users[m.SenderId] : null,
                Receiver = m.ReceiverId,
                m.GroupId,
                m.Content,
                m.SentAtUtc
            }));
        }
    }
}

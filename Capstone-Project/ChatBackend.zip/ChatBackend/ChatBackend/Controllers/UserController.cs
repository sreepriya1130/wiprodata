﻿using ChatBackend.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ChatBackend.Data;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class UsersController : ControllerBase
{
    private readonly UserManager<User> _um;
    private readonly ApplicationDbContext _context;

    public UsersController(UserManager<User> um, ApplicationDbContext context)
    {
        _um = um;
        _context = context;
    }

    // ✅ 1. Get all users except logged-in one + last private message
    [HttpGet("list")]
    public async Task<IActionResult> GetUsersWithLastMessage()
    {
        // Extract logged-in user ID from JWT
        var meId = User.FindFirstValue(ClaimTypes.NameIdentifier)
                   ?? User.FindFirstValue(JwtRegisteredClaimNames.Sub);

        if (string.IsNullOrEmpty(meId))
            return Unauthorized("Could not determine logged-in user ID.");

        var users = await _um.Users
            .Where(u => u.Id != meId)
            .ToListAsync();

        var result = new List<object>();

        foreach (var u in users)
        {
            var lastMsg = await _context.Messages
                .Where(m =>
                    (m.SenderId == meId && m.ReceiverId == u.Id) ||
                    (m.SenderId == u.Id && m.ReceiverId == meId))
                .OrderByDescending(m => m.SentAtUtc)
                .FirstOrDefaultAsync();

            result.Add(new
            {
                u.Id,
                u.DisplayName,
                u.Email,
                u.Status,
                u.LastSeenUtc,
                LastMessage = lastMsg != null ? new
                {
                    lastMsg.Content,
                    lastMsg.SentAtUtc,
                    Sender = lastMsg.SenderId == meId ? "You" : u.DisplayName
                } : null
            });
        }

        return Ok(result);
    }

    // ✅ 2. Get all registered users (debug / admin use)
    [HttpGet("all")]
    public async Task<IActionResult> GetAllUsers()
    {
        var users = await _um.Users
            .Select(u => new
            {
                u.Id,
                u.DisplayName,
                u.Email,
                u.Status,
                u.LastSeenUtc
            })
            .ToListAsync();

        return Ok(users);
    }
}

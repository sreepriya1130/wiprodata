﻿using ChatBackend.Data;
using ChatBackend.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class GroupController : ControllerBase
{
    private readonly ApplicationDbContext _db;
    private readonly UserManager<User> _um;

    public GroupController(ApplicationDbContext db, UserManager<User> um)
    {
        _db = db;
        _um = um;
    }

    // DTOs
    public record CreateGroupDto(string Name, List<string> UsernamesOrEmails);
    public record EditGroupMembersDto(int GroupId, List<string> Usernames);
    public record SendGroupMessageDto(int GroupId, string Content);

    // ✅ Create Group
    [HttpPost("create")]
    public async Task<IActionResult> Create([FromBody] CreateGroupDto dto)
    {
        var meId = User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (string.IsNullOrEmpty(meId))
            return Unauthorized("Could not determine logged-in user ID.");

        var g = new Group { Name = dto.Name };
        _db.Groups.Add(g);
        await _db.SaveChangesAsync();

        var validMembers = new List<string>();

        // Add creator as admin
        _db.GroupMembers.Add(new GroupMember
        {
            GroupId = g.Id,
            UserId = meId,
            Role = "admin"
        });

        var creator = await _um.FindByIdAsync(meId);
        if (creator != null)
            validMembers.Add(creator.DisplayName ?? creator.UserName ?? creator.Email ?? creator.Id);

        // Add other members
        foreach (var entry in dto.UsernamesOrEmails.Distinct())
        {
            var user = await _um.Users
                .FirstOrDefaultAsync(u => u.DisplayName == entry || u.UserName == entry || u.Email == entry);

            if (user != null && user.Id != meId)
            {
                _db.GroupMembers.Add(new GroupMember
                {
                    GroupId = g.Id,
                    UserId = user.Id,
                    Role = "member"
                });

                validMembers.Add(user.DisplayName ?? user.UserName ?? user.Email ?? user.Id);
            }
        }

        await _db.SaveChangesAsync();

        return Ok(new
        {
            Message = "Group created successfully",
            Group = new { g.Id, g.Name },
            Members = validMembers
        });
    }

    // ✅ Send Message
    [HttpPost("send-message")]
    public async Task<IActionResult> SendMessage([FromBody] SendGroupMessageDto dto)
    {
        var meId = User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (string.IsNullOrEmpty(meId))
            return Unauthorized("Could not determine logged-in user ID.");

        var group = await _db.Groups.FindAsync(dto.GroupId);
        if (group == null)
            return NotFound($"Group with Id {dto.GroupId} does not exist.");

        bool isMember = await _db.GroupMembers
            .AnyAsync(gm => gm.GroupId == dto.GroupId && gm.UserId == meId);

        if (!isMember)
            return Unauthorized("You are not a member of this group.");

        if (string.IsNullOrWhiteSpace(dto.Content))
            return BadRequest("Message content cannot be empty.");

        var msg = new Message
        {
            SenderId = meId,
            GroupId = dto.GroupId,
            Content = dto.Content,
            SentAtUtc = DateTime.UtcNow
        };

        _db.Messages.Add(msg);
        await _db.SaveChangesAsync();

        var sender = await _um.FindByIdAsync(meId);

        return Ok(new
        {
            msg.Id,
            Group = new { group.Id, group.Name },
            Sender = sender?.DisplayName ?? sender?.UserName ?? sender?.Email ?? "Unknown",
            msg.Content,
            msg.SentAtUtc
        });
    }

    // ✅ Add Members
    [HttpPost("add-members")]
    public async Task<IActionResult> AddMembers([FromBody] EditGroupMembersDto dto)
    {
        var group = await _db.Groups.FindAsync(dto.GroupId);
        if (group == null) return NotFound("Group not found.");

        var addedMembers = new List<string>();

        foreach (var username in dto.Usernames.Distinct())
        {
            var user = await _um.Users
                .FirstOrDefaultAsync(u => u.DisplayName == username || u.UserName == username || u.Email == username);

            if (user == null) continue;

            bool alreadyMember = await _db.GroupMembers
                .AnyAsync(gm => gm.GroupId == dto.GroupId && gm.UserId == user.Id);

            if (!alreadyMember)
            {
                _db.GroupMembers.Add(new GroupMember
                {
                    GroupId = dto.GroupId,
                    UserId = user.Id,
                    Role = "member"
                });
                addedMembers.Add(user.DisplayName ?? user.UserName ?? user.Email ?? user.Id);
            }
        }

        await _db.SaveChangesAsync();

        if (!addedMembers.Any())
            return BadRequest("No valid users found or all users are already members.");

        return Ok(new { Message = "Members added.", Members = addedMembers });
    }

    // ✅ Remove Members
    [HttpPost("remove-members")]
    public async Task<IActionResult> RemoveMembers([FromBody] EditGroupMembersDto dto)
    {
        var group = await _db.Groups.FindAsync(dto.GroupId);
        if (group == null) return NotFound("Group not found.");

        var removedMembers = new List<string>();

        foreach (var username in dto.Usernames.Distinct())
        {
            var user = await _um.Users
                .FirstOrDefaultAsync(u => u.DisplayName == username || u.UserName == username || u.Email == username);

            if (user == null) continue;

            var gm = await _db.GroupMembers
                .FirstOrDefaultAsync(x => x.GroupId == dto.GroupId && x.UserId == user.Id);

            if (gm != null)
            {
                _db.GroupMembers.Remove(gm);
                removedMembers.Add(user.DisplayName ?? user.UserName ?? user.Email ?? user.Id);
            }
        }

        await _db.SaveChangesAsync();

        if (!removedMembers.Any())
            return BadRequest("No valid users found in the group.");

        return Ok(new { Message = "Members removed.", Members = removedMembers });
    }

    // ✅ Get Members
    [HttpGet("{groupId}/members")]
    public async Task<IActionResult> GetGroupMembers(int groupId)
    {
        var group = await _db.Groups.FindAsync(groupId);
        if (group == null) return NotFound("Group not found.");

        var members = await _db.GroupMembers
            .Where(gm => gm.GroupId == groupId)
            .Join(_um.Users,
                  gm => gm.UserId,
                  u => u.Id,
                  (gm, u) => new
                  {
                      u.Id,
                      u.DisplayName,
                      u.UserName,
                      u.Email,
                      gm.Role
                  })
            .ToListAsync();

        return Ok(members);
    }

    // ✅ Get groups for current user
    [HttpGet("list")]
    public async Task<IActionResult> ListGroups()
    {
        var meId = User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (string.IsNullOrEmpty(meId))
            return Unauthorized("Could not determine logged-in user ID.");

        var groups = await _db.GroupMembers
            .Where(gm => gm.UserId == meId)
            .Include(gm => gm.Group)
            .Select(gm => new
            {
                gm.Group.Id,
                gm.Group.Name
            })
            .ToListAsync();

        return Ok(groups);
    }

    // ✅ Get group chat history
    [HttpGet("{groupId}/messages")]
    public async Task<IActionResult> GetGroupMessages(int groupId)
    {
        var meId = User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (string.IsNullOrEmpty(meId))
            return Unauthorized("Could not determine logged-in user ID.");

        bool isMember = await _db.GroupMembers
            .AnyAsync(gm => gm.GroupId == groupId && gm.UserId == meId);

        if (!isMember)
            return Unauthorized("You are not a member of this group.");

        var messages = await _db.Messages
            .Where(m => m.GroupId == groupId)
            .OrderBy(m => m.SentAtUtc)
            .Join(_um.Users,
                  m => m.SenderId,
                  u => u.Id,
                  (m, u) => new
                  {
                      m.Id,
                      Sender = u.DisplayName ?? u.UserName ?? u.Email ?? "Unknown",
                      m.Content,
                      m.SentAtUtc
                  })
            .ToListAsync();

        return Ok(messages);
    }
}

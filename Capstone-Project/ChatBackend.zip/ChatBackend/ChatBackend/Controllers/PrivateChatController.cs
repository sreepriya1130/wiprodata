﻿using ChatBackend.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using Microsoft.EntityFrameworkCore;


namespace ChatBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PrivateChatController : ControllerBase
    {
        private readonly ApplicationDbContext _db;

        public PrivateChatController(ApplicationDbContext db)
        {
            _db = db;
        }

        [HttpPost("send")]
        public async Task<IActionResult> SendPrivate([FromBody] PrivateMessage dto)
        {
            dto.SentAtUtc = DateTime.UtcNow;
            _db.PrivateMessages.Add(dto);
            await _db.SaveChangesAsync();
            return Ok(dto);
        }

        [HttpGet("{userId}")]
        public async Task<IActionResult> GetMessages(string userId)
        {
            var meId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            var msgs = await _db.PrivateMessages
                .Where(m =>
                    (m.SenderId == meId && m.ReceiverId == userId) ||
                    (m.SenderId == userId && m.ReceiverId == meId))
                .OrderBy(m => m.SentAtUtc)
                .ToListAsync();

            return Ok(msgs);
        }
    }
}

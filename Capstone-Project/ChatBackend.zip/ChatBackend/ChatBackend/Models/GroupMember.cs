﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ChatBackend.Models
{
    public class GroupMember
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int GroupId { get; set; }

        [ForeignKey("GroupId")]
        public Group? Group { get; set; }

        [Required]
        public string UserId { get; set; } = string.Empty;

        // Add Role property
        [Required]
        [MaxLength(50)]
        public string Role { get; set; } = "member";
    }
}

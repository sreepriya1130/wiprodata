﻿using ChatBackend.Data;
using ChatBackend.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace ChatBackend.Hubs
{
    [Authorize]
    public class ChatHub : Hub
    {
        private readonly ApplicationDbContext _db;
        private readonly UserManager<User> _um;

        public ChatHub(ApplicationDbContext db, UserManager<User> um)
        {
            _db = db;
            _um = um;
        }

        public override async Task OnConnectedAsync()
        {
            var userId = GetUserId();
            if (!string.IsNullOrEmpty(userId))
            {
                var user = await _um.FindByIdAsync(userId);
                if (user != null)
                {
                    user.IsOnline = true;
                    await _um.UpdateAsync(user);

                    // Notify all clients user came online
                    await Clients.All.SendAsync("UserOnline", new
                    {
                        user.Id,
                        user.DisplayName
                    });

                    // Auto join user’s groups
                    var groups = await _db.GroupMembers
                        .Where(gm => gm.UserId == userId)
                        .Select(gm => gm.GroupId.ToString())
                        .ToListAsync();

                    foreach (var groupId in groups)
                        await Groups.AddToGroupAsync(Context.ConnectionId, groupId);
                }
            }

            await base.OnConnectedAsync();
        }

        public override async Task OnDisconnectedAsync(Exception? exception)
        {
            var userId = GetUserId();
            if (!string.IsNullOrEmpty(userId))
            {
                var user = await _um.FindByIdAsync(userId);
                if (user != null)
                {
                    user.IsOnline = false;
                    user.LastSeenUtc = DateTime.UtcNow;
                    await _um.UpdateAsync(user);

                    await Clients.All.SendAsync("UserOffline", new
                    {
                        user.Id,
                        user.DisplayName,
                        user.LastSeenUtc
                    });
                }
            }

            await base.OnDisconnectedAsync(exception);
        }

        // ✅ Extract logged-in userId
        private string? GetUserId()
        {
            return Context.User?.FindFirstValue(ClaimTypes.NameIdentifier)
                ?? Context.User?.FindFirstValue(JwtRegisteredClaimNames.Sub);
        }

        // ✅ Send private message
        public async Task SendPrivate(string receiverDisplayName, string content)
        {
            var meId = GetUserId();
            if (string.IsNullOrEmpty(meId)) return;

            var receiver = await _um.Users.FirstOrDefaultAsync(u => u.DisplayName == receiverDisplayName);
            if (receiver == null) return;

            var msg = new Message
            {
                SenderId = meId,
                ReceiverId = receiver.Id,
                Content = content,
                SentAtUtc = DateTime.UtcNow
            };

            _db.Messages.Add(msg);
            await _db.SaveChangesAsync();

            var sender = await _um.FindByIdAsync(meId);

            var payload = new
            {
                msg.Id,
                Sender = sender?.DisplayName ?? "Unknown",
                Receiver = receiver.DisplayName,
                msg.Content,
                msg.SentAtUtc
            };

            // Deliver to receiver + echo back to sender
            await Clients.User(receiver.Id).SendAsync("ReceivePrivateMessage", payload);
            await Clients.User(meId).SendAsync("ReceivePrivateMessage", payload);
        }

        // ✅ Send group message
        public async Task SendGroup(int groupId, string content)
        {
            var meId = GetUserId();
            if (string.IsNullOrEmpty(meId)) return;

            var msg = new Message
            {
                SenderId = meId,
                GroupId = groupId,
                Content = content,
                SentAtUtc = DateTime.UtcNow
            };

            _db.Messages.Add(msg);
            await _db.SaveChangesAsync();

            var sender = await _um.FindByIdAsync(meId);

            var payload = new
            {
                msg.Id,
                Sender = sender?.DisplayName ?? "Unknown",
                msg.GroupId,
                msg.Content,
                msg.SentAtUtc
            };

            await Clients.Group(groupId.ToString()).SendAsync("ReceiveGroupMessage", payload);
        }

        // ✅ Typing indicator
        public async Task Typing(string toDisplayName)
        {
            var meId = GetUserId();
            if (string.IsNullOrEmpty(meId)) return;

            var receiver = await _um.Users.FirstOrDefaultAsync(u => u.DisplayName == toDisplayName);
            if (receiver == null) return;

            var sender = await _um.FindByIdAsync(meId);

            await Clients.User(receiver.Id).SendAsync("Typing", new
            {
                Sender = sender?.DisplayName
            });
        }

        // ✅ Group membership helpers
        public async Task JoinGroup(int groupId)
        {
            await Groups.AddToGroupAsync(Context.ConnectionId, groupId.ToString());
        }

        public async Task LeaveGroup(int groupId)
        {
            await Groups.RemoveFromGroupAsync(Context.ConnectionId, groupId.ToString());
        }
    }
}
